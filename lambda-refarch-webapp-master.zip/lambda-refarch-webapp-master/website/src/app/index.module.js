(function() {
  'use strict';

  angular
    .module('ServerlessBlog', [
    	'ngAnimate', 
    	'ngCookies', 
    	'ngSanitize', 
    	'ngMessages', 
    	'ngAria', 
    	'ui.router', 
    	'ngMaterial', 
    	'toastr'
    	]
	);

})();
